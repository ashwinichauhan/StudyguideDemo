package com.example.studyguide;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class HomePageActivity extends AppCompatActivity {

    private Button Review;
    private Button Set;
    private Button Quiz;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        setupUIViews();

        mAuth = FirebaseAuth.getInstance();

        Review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePageActivity.this, ReviewActivity.class));
            }
        });

        Set.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePageActivity.this, SetActivity.class));
            }
        });

        Quiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePageActivity.this, TestYourselfActivity.class));
            }
        });
    }

    private void signout() {
        mAuth.signOut();
        finish();
        startActivity(new Intent(HomePageActivity.this, MainActivity.class));

    }

    private void setupUIViews() {
        Review = (Button)findViewById(R.id.buttonReview);
        Set = (Button)findViewById(R.id.buttonSet);
        Quiz = (Button)findViewById(R.id.buttonTestYourself);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logoutMenu: {
                signout();
            }
        }
        return super.onOptionsItemSelected(item);
    }
}
