package com.example.studyguide;

public class Topics {
    public String UserQuestion;
    public String UserAnswer;
    public String UserTitle;

    public Topics(String userQuestion, String userAnswer) {
        UserQuestion = userQuestion;
        UserAnswer = userAnswer;
    }
}
